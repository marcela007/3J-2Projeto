julia 3j
